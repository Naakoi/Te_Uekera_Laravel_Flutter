package com.teuekera.mobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
