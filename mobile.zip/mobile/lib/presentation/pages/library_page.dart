import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:google_fonts/google_fonts.dart';
import '/data/models/document_model.dart';
import '/presentation/blocs/document_bloc.dart';
import '/presentation/blocs/document_state.dart';
import 'document_details_page.dart';

class LibraryPage extends StatelessWidget {
  const LibraryPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFf4f1ea),
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        title: Text(
          'YOUR LIBRARY',
          style: GoogleFonts.playfairDisplay(
            color: const Color(0xFF1a1a1a),
            fontWeight: FontWeight.w900,
            fontSize: 24,
          ),
        ),
        centerTitle: true,
      ),
      body: BlocBuilder<DocumentBloc, DocumentState>(
        builder: (context, state) {
          if (state is DocumentLoading) {
            return const Center(child: CircularProgressIndicator(color: Color(0xFFbe1e2d)));
          } else if (state is DocumentLoaded) {
            final myDocuments = state.documents.where((doc) => doc.hasAccess).toList();

            if (myDocuments.isEmpty) {
              return Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.library_books_outlined, size: 64, color: Colors.grey),
                    const SizedBox(height: 16),
                    Text(
                      'Your library is empty.',
                      style: GoogleFonts.inter(fontSize: 16, color: Colors.grey),
                    ),
                  ],
                ),
              );
            }

            return ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: myDocuments.length,
              itemBuilder: (context, index) {
                final document = myDocuments[index];
                return _buildLibraryItem(context, document);
              },
            );
          } else if (state is DocumentError) {
            return Center(child: Text(state.message));
          }
          return const SizedBox.shrink();
        },
      ),
    );
  }

  Widget _buildLibraryItem(BuildContext context, DocumentModel document) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.05), blurRadius: 10, offset: const Offset(0, 4)),
        ],
      ),
      child: ListTile(
        contentPadding: const EdgeInsets.all(16),
        leading: Container(
          width: 60,
          height: 80,
          decoration: BoxDecoration(
            color: Colors.grey[200],
            borderRadius: BorderRadius.circular(8),
            image: document.thumbnailPath != null
                ? DecorationImage(
                    image: NetworkImage('http://127.0.0.1:8000/api/images/${document.thumbnailPath}'),
                    fit: BoxFit.cover,
                  )
                : null,
          ),
          child: document.thumbnailPath == null
              ? const Icon(Icons.newspaper, color: Colors.grey)
              : null,
        ),
        title: Text(
          document.title,
          style: GoogleFonts.inter(fontWeight: FontWeight.bold, fontSize: 16),
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
        ),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const SizedBox(height: 4),
            Text(
              document.publishedAt?.toString().split(' ')[0] ?? 'Unknown Date',
              style: GoogleFonts.inter(fontSize: 12, color: Colors.grey),
            ),
            const SizedBox(height: 8),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.1),
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                'PURCHASED',
                style: GoogleFonts.inter(fontSize: 10, fontWeight: FontWeight.bold, color: Colors.green),
              ),
            ),
          ],
        ),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => DocumentDetailsPage(document: document),
            ),
          );
        },
      ),
    );
  }
}
